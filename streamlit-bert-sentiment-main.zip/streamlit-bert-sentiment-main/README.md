# streamlit-bert-sentiment
# Streamlit BERT Sentiment Analysis

This app uses a pre-trained BERT model to predict sentiment from text using Streamlit.

## Run Locally

```bash
pip install -r requirements.txt
streamlit run app.py
